<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "airport".
 *
 * @property integer $id
 * @property string $airport_code
 * @property string $airport_name
 * @property string $country
 * @property string $city
 */
class Airport extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'airport';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['airport_code', 'airport_name', 'country', 'city'], 'required'],
            [['airport_code'], 'string', 'max' => 10],
            [['airport_name'], 'string', 'max' => 30],
            [['country', 'city'], 'string', 'max' => 20],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'airport_code' => Yii::t('app', 'Airport Code'),
            'airport_name' => Yii::t('app', 'Airport Name'),
            'country' => Yii::t('app', 'Country'),
            'city' => Yii::t('app', 'City'),
        ];
    }
}
