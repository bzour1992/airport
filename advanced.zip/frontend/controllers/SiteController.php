<?php
namespace frontend\controllers;

use backend\models\Airport;
use Yii;
use yii\web\Controller;
use yii\web\Response;

/**
 * Site controller
 */
class SiteController extends Controller
{
    /**
     * @inheritdoc
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
        ];
    }

    public function actionRead()
    {
        Yii::$app->response->format = Response::FORMAT_JSON;
        if (isset($_GET['id'])) {
            $model = Airport::findOne(['airport_code' => $_GET['id']]);
            if ($model) {
                return [
                    'ok' => true,
                    'message' => 'Successful',
                    'airport' => $model->attributes,
                ];
            } else {
                return [
                    'ok' => false,
                    'message' => 'Not Found',
                ];
            }
        } else {
            return [
                'ok' => false,
                'message' => 'please enter parameter \'id\'',
            ];
        }
    }

    public function actionUpdate()
    {
        Yii::$app->response->format = Response::FORMAT_JSON;
        $model = Airport::findOne(['airport_code' => $id]);
        if ($model) {
            return [
                'ok' => true,
                'message' => 'Successful',
                'airport' => $model->attributes,
            ];
        } else {
            return [
                'ok' => false,
                'message' => 'Not Found',
            ];
        }
    }
}
